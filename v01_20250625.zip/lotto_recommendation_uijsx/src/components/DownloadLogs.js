import React from "react";

function DownloadLogs() {
  return (
    <div className="mt-2">
      <button className="bg-green-600 text-white px-4 py-2 rounded">CSV 다운로드</button>
    </div>
  );
}

export default DownloadLogs;

import React from "react";

function ChartView() {
  return (
    <div className="p-4 bg-white rounded-xl shadow-md mb-4">
      <h2 className="text-lg font-semibold mb-2">전략별 적중 수 그래프</h2>
      <p className="text-sm text-gray-500">그래프 준비 중...</p>
    </div>
  );
}

export default ChartView;

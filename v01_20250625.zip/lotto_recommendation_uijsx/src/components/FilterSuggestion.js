import React from "react";

function FilterSuggestion() {
  return (
    <div className="p-4 bg-white rounded-xl shadow-md">
      <h2 className="text-lg font-semibold mb-2">추천 필터 목록</h2>
      <p className="text-sm text-gray-500">불러온 필터가 없습니다.</p>
    </div>
  );
}

export default FilterSuggestion;

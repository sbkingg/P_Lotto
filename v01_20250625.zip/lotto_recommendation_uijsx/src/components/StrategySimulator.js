import React from "react";

function StrategySimulator() {
  return (
    <div className="p-4 bg-white rounded-xl shadow-md mt-4">
      <h2 className="text-lg font-semibold mb-2">전략 시뮬레이터</h2>
      <button className="bg-blue-600 text-white px-4 py-2 rounded">시뮬레이션 실행</button>
    </div>
  );
}

export default StrategySimulator;
